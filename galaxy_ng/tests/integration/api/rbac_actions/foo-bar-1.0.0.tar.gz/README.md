# Ansible Collection - foo.bar

Documentation for the collection.